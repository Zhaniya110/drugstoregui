package com.zhaniya;

public record MainUI() {
}
