package com.zhaniya.ui;



import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

public class MainUI {
    private JPanel rootPanel;
    private JLabel DrugStoreLabel;
    private JTextField textField;
    private JButton deleteButton;
    private JButton AddButton;
    private JTable table1;
    private JButton searchButton;
    private JTextField textField1;
    private JTextField textField2;
    private JComboBox CountryCombo;
    private JComboBox DateCombo;

    public MainUI(){
        createTable();
        createCountryCombo();
        createDateCombo();
         }

    private void createCountryCombo() {
        CountryCombo.setModel(new DefaultComboBoxModel(new String[]{ "USA","UK","China","France","Australia","India"}));
    }
    private void createDateCombo() {
        DateCombo.setModel(new DefaultComboBoxModel(new String[]{"2021-2022","2022-2023","2023-2024","2024-2025"}));
    }

    public JPanel getRootPanel( ){
     return rootPanel;
    }
    private void createTable(){
        Object data[][]= {
            {"paracetamol",3,2023-11-11,"France"},
            {"Diazepam",15,2023-9-3,"USA"},
            {"Alprazolam",10,2022-5-22,"USA"}
        };
        table1.setModel(new DefaultTableModel(
                data,
                new String[]{"name","price","expiration date","manufacturer"}
        ));
         TableColumnModel columns = table1.getColumnModel();
            }

    public void setVisible(boolean b) {
    }
}
