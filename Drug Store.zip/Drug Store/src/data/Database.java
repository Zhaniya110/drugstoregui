package data;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static java.lang.System.exit;

public class Database {
    public static Connection connection = null;
    private static String CONN_STRING ="jdbc:postgresql://localhost:5432/DrugStore";
    private static String USERNAME = "postgres";
    private static String PASSWORD ="Qwe53215";
    public void connect(){
      if(connection != null) {
          return;
      } else {
          try {
              connection = DriverManager.getConnection(CONN_STRING,USERNAME,PASSWORD);
          } catch (SQLException e) {
              e.printStackTrace();
              exit(-1);

          }
      }
    }
}
